﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ATMApplicationn.Models;

namespace ATMApplicationn
{
    public partial class FormNewAccount : Form
    {
        public FormNewAccount()
        {
            InitializeComponent();
        }

        private void FormNewAccount_Load(object sender, EventArgs e)
        {

        }

        private void txtPIN_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            btnRegister.Enabled = false;
            string AccountNo = txtAccountNo.Text;
            string PIN = txtPIN.Text;
            string FullName = txtFullName.Text;

            if (String.IsNullOrEmpty(AccountNo) || string.IsNullOrEmpty(PIN) || string.IsNullOrEmpty(FullName))
            {
                MessageBox.Show("Please enter value for all form fields.");
            }
            else
            {
                var AccountInfo = Form1.AccountsList.FirstOrDefault(a => a.AccountNo == AccountNo);
                if (AccountInfo != null)
                {
                    MessageBox.Show("An account already exists with this number.");
                }
                else 
                {
                    Account account = new Account();
                    account.AccountNo = AccountNo;
                    account.FullName = FullName;
                    account.PIN = PIN;

                    Form1.AccountsList.Add(account);
                    MessageBox.Show("Account created successfully");
                    this.Close();

                }
                
            }

            btnRegister.Enabled = true;
        }
    }
}
