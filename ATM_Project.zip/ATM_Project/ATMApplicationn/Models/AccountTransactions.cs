﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMApplicationn.Models
{
    public class AccountTransactions
    {
        public decimal Amount { get; set; }
        public DateTime Dated { get; set; }
    }
}
