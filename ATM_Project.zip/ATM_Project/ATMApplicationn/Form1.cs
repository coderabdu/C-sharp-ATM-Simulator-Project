﻿using ATMApplicationn.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMApplicationn
{
    public partial class Form1 : Form
    {
        public static  List<Account> AccountsList;
        public Form1()
        {
            InitializeComponent();
            AccountsList = new List<Account>();

            AccountsList.Add(new Account() { AccountNo = "1001", FullName = "John Gold", PIN = "3214" });

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPIN_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            FormNewAccount form = new FormNewAccount();
            form.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;
            string AccountNo = txtAccountNo.Text;
            string PIN = txtPIN.Text;

            if (String.IsNullOrEmpty(AccountNo) || string.IsNullOrEmpty(PIN))
            {
                MessageBox.Show("Please enter Account Number and PIN");
            }
            else
            {
                var AccountInfo = AccountsList.FirstOrDefault(a => a.AccountNo == AccountNo && a.PIN == PIN);
                if (AccountInfo == null)
                {
                    MessageBox.Show("InvalidAccount or PIN.");
                }
                else
                {
                    FormBanking form = new FormBanking();
                    form.AccountInfo = AccountInfo;
                    
                    form.ShowDialog();
                }
            }
            btnLogin.Enabled = true;

        }
    }
}
