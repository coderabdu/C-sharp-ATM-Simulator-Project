﻿using ATMApplicationn.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMApplicationn
{
    public partial class FormBanking : Form
    {
        public Account AccountInfo;


        public FormBanking()
        {
            InitializeComponent();
        }

        private void FormBanking_Load(object sender, EventArgs e)
        {
            DisplayAccountInfo();
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            decimal DepositAmount = nudDeposit.Value;

            AccountTransactions transaction = new AccountTransactions();
            transaction.Amount = DepositAmount;
            transaction.Dated = DateTime.Now;
            AccountInfo.Transations.Add(transaction);
            AccountInfo.Balance += DepositAmount;

            DisplayAccountInfo();
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            decimal WithdrawAmount = nudWithdraw.Value;

            if (AccountInfo.Balance >= WithdrawAmount)
            {
                AccountTransactions transaction = new AccountTransactions();
                transaction.Amount = WithdrawAmount;
                transaction.Dated = DateTime.Now;
                AccountInfo.Transations.Add(transaction);

                AccountInfo.Balance -= WithdrawAmount;
            }
            else
            {
                MessageBox.Show("Insufficient funds to withdraw");
            }

            DisplayAccountInfo();

        }

        void DisplayAccountInfo()
        {

            if (AccountInfo != null)
            {
                lblAccountNo.Text = AccountInfo.AccountNo;
                lblFullName.Text = AccountInfo.FullName;
                lblBalance.Text = AccountInfo.Balance.ToString("C2");

                dataGridView1.DataSource = null;

                dataGridView1.DataSource = AccountInfo.Transations;
            }
        }
            
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
           
        }
        
    }
}
